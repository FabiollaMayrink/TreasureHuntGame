/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package treasurehunt;

/**
 *
 * @author gabri
 */
class myPlayers {
    
    private String playerFullname;
    private int userAge;
    private int playerStatus;

    /**
     * @return the playerFullname
     */
    public String getPlayerFullname() {
        return playerFullname;
    }

    /**
     * @param playerFullname the playerFullname to set
     */
    public void setPlayerFullname(String playerFullname) {
        this.playerFullname = playerFullname;
    }

    /**
     * @return the userAge
     */
    public int getUserAge() {
        return userAge;
    }

    /**
     * @param userAge the userAge to set
     */
    public void setUserAge(int userAge) {
        this.userAge = userAge;
    }

    /**
     * @return the playerStatus
     */
    public int getPlayerStatus() {
        return playerStatus;
    }

    /**
     * @param playerStatus the playerStatus to set
     */
    public void setPlayerStatus(int playerStatus) {
        this.playerStatus = playerStatus;
    }
    
}
